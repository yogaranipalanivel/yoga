package class2;

public class Player {
	String PlayerName;
	String PlayerPosition;
	public Player(String playerName, String playerPosition) {
		super();
		this.PlayerName = playerName;
		this.PlayerPosition = playerPosition;
		System.out.println("PlayerNmae "+PlayerName+" PlayerPosition "+PlayerPosition);
	}
	

}
