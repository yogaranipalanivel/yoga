package class1;

public class Team {
	String TeamName;
	String City;
	public Team(String teamName, String city) {
		super();
		this.TeamName = teamName;
		this.City = city;
		System.out.println("TeamName "+TeamName+" City "+City); 
	}
	

}
